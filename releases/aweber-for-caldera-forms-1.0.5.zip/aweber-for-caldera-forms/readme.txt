=== Awber for Caldera Forms ===
Contributors:      Shelob9, Desertsnowman
Donate link:       https://calderawp.com
Tags:              calderawp, caldera forms, wpform, form, responsive
Requires at least: 4.0
Tested up to:      4.9.5
Stable tag: 1.0.5
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html

Awber for Caldera Forms

== Description ==



== Installation ==

= Manual Installation =

1. Upload the entire `/awber-for-caldera-forms` directory to the `/wp-content/plugins/` directory.
2. Activate Awber for Caldera Forms through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1.0 =
* First release

== Upgrade Notice ==

= 1.0.5 =
* FIXED: Bug that prevent users ti be added to list
* FIXED: Removed Warninh that showed during Aweber connection
* ADDED: Meaningful Log notices

= 0.1.0 =
First Release
